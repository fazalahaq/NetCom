
package Main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LaunchBrowser {
	public static void main(String[] args) {
		// Set the path for the ChromeDriver executable
		// System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

		// Initialize the ChromeDriver
		WebDriver driver = new ChromeDriver();

		try {
			// Open the URL
			driver.get("https://www.netcomlearning.com/course/ai-cloud");
			driver.manage().window().maximize();

			// Create a WebDriverWait instance
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

			// Click on the search icon
			WebElement searchIcon = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='search-icon']")));
			searchIcon.click();

			// Enter text in the search box
			WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("search-box")));
			searchBox.sendKeys("AI");

			// Click on the search button
			WebElement searchButton = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='search-button']")));
			searchButton.click();

			// Click on the desired table cell

			WebElement tableCell = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
					"//*[@id='__next']/div/div[2]/div/div[3]/div[2]/div[1]/div[1]/div/div/div/table/tbody/tr[1]/td[3]/button")));
			
			tableCell.click();

			Thread.sleep(5000);

			WebElement cartButton = wait.until(ExpectedConditions
					.elementToBeClickable(By.xpath("//*[@id=\"header\"]/div/div/div[2]/div/a/span/div/span/img")));

			cartButton.click();

			// Get the value of the input field
			WebElement inputField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
					"//*[@id=\"__next\"]/div/div[1]/div[2]/div/div/div[1]/div[3]/div/div/div/div[3]/div[1]/div/input")));
			String inputValue = inputField.getAttribute("value"); // Get the value of the input field

			// Validate the value
			String expectedValue = "1"; // Replace with the value you want to validate against
			if (inputValue.equals(expectedValue)) {
				System.out.println("Validation successful: The input value is as expected.");
			} else {
				System.out
						.println("Validation failed: Expected '" + expectedValue + "' but found '" + inputValue + "'.");
			}

			WebElement updatecartitem = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
					"//*[@id=\"__next\"]/div/div[1]/div[2]/div/div/div[1]/div[3]/div/div/div/div[3]/div[1]/div/div/div[1]")));

			updatecartitem.click();
			Thread.sleep(5000);

			System.out.println("1111111111111111");
			// Get the value from the specified XPath
			WebElement headingElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath("//*[@id='__next']/div/div[1]/div[2]/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/h3")));
			String headingText = headingElement.getText(); // Get the text of the heading

			// Validate the value
			String expectedprice = "$ 1,990"; // Replace with the value you want to validate against
			if (headingText.equals(expectedprice)) {
				System.out.println("Validation successful: The heading text is as expected.");
				System.out.println(
						"Validation failed: Expected '" + expectedprice + "' but found '" + headingText + "'.");
			}

			// Remove the Item

			WebElement Remove = wait.until(ExpectedConditions
					.elementToBeClickable(By.xpath("//*[@id=\"__next\"]/div/div[1]/div[2]/div/div/div[1]/div[3]/div/div/div/div[3]/div[2]")));
			Remove.click();
			
			//
			WebElement RemoveYes = wait.until(ExpectedConditions
					.elementToBeClickable(By.xpath("/html/body/div[7]/div/div[2]/div/div[2]/div/div/button[1]")));
			RemoveYes.click();
			Thread.sleep(5000);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Close the browser
			driver.quit();
		}
	}
}